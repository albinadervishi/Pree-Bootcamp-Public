var count1 = 9;
var count2 = 12;
var count3 = 10;


var arr=[1, 2, 3];


function add1(element) {
  var countElement = document.getElementById(element);
  var postNumber = arr.slice(0,1,2);
  if (postNumber == "1") {
    count1++;
    countElement.innerText = count1 + " like(s)";
    return count1;
  } else if (postNumber == "2") {
    count2++;
    countElement.innerText = count2 + " like(s)";
    return count2;
  } else if (postNumber == "3") {
    count3++;
    countElement.innerText = count3 + " like(s)";
    return count3;
  } 
}